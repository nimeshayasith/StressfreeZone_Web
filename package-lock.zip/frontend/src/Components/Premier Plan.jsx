import React from 'react';

const PremierPlanPage = () => {
    return (
        <div>
            <h1>PremierPlan</h1>
            {/* Your about us content */}
        </div>
    );
}

export default PremierPlanPage;