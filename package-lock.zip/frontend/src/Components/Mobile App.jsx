import React from 'react';

const MobileAppPage = () => {
    return (
        <div>
            <h1>mobileapp</h1>
            {/* Your about us content */}
        </div>
    );
}

export default MobileAppPage;